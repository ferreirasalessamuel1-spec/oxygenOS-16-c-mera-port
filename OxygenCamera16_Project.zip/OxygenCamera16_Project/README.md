# Oxygen Camera 16 — projeto inicial

Projeto Android nativo inspirado visualmente na câmera OxygenOS. Não é um port oficial da OnePlus.

## O que já está implementado
- Preview ao vivo da câmera.
- Foto salva em `Pictures/OxygenCamera16`.
- Gravação de vídeo Full HD (quando o dispositivo suporta), salva em `Movies/OxygenCamera16`.
- Alternância entre câmera traseira e frontal.
- Zoom usando os limites informados pela câmera.
- Lanterna/flash contínuo quando disponível.
- Interface escura com painéis translúcidos.

## O que ainda não está implementado
Modo noturno computacional, modo Pro manual completo, vídeo Pro, retrato com segmentação/desfoque real, HDR avançado, câmera lenta e controles específicos do ISP. Esses recursos exigem implementação adicional e/ou suporte do hardware e APIs do aparelho. A interface não deve anunciar esses recursos como funcionais antes de serem implementados.

## Como compilar
1. Abra a pasta `OxygenCamera16` no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Se necessário, instale Android SDK 35 e JDK 17 pelo Android Studio.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração normalmente será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalação no OPPO A40
Transfira `app-debug.apk` para o telefone, abra pelo gerenciador de arquivos e permita a instalação para essa origem quando o Android solicitar. Instale somente o APK que você mesmo compilou a partir deste projeto.

## Compatibilidade
Alvo inicial: Android 8.0+; testagem necessária no OPPO A40/Android 14. CameraX escolhe formatos conforme os recursos expostos pelo fabricante. O app não desbloqueia capacidades físicas ausentes.

## Compilar sem PC usando GitHub Actions (pelo navegador do celular)
1. Crie uma conta no GitHub, se ainda não tiver, e crie um repositório vazio.
2. No navegador do celular, abra o repositório e use **Add file > Upload files** para enviar o conteúdo desta pasta (incluindo a pasta `.github/workflows`).
3. Confirme o envio para a branch `main`.
4. Abra a aba **Actions** do repositório. O workflow **Build Oxygen Camera 16 APK** deve iniciar automaticamente; se não iniciar, abra-o e toque em **Run workflow**.
5. Quando terminar com sucesso, abra a execução e baixe o artefato `OxygenCamera16-debug-apk`. Extraia o ZIP do artefato para obter `app-debug.apk`.
6. No OPPO, abra o APK e permita a instalação para o navegador/gerenciador de arquivos quando solicitado.

O GitHub compila o projeto em seus servidores; não é necessário instalar Android Studio no telefone. O APK gerado é de depuração e não é publicado na Play Store.
