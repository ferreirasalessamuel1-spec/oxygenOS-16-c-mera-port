package com.example.oxygencamera16

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var executor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var camera: Camera? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var videoMode = false
    private var torchOn = false
    private lateinit var captureButton: Button
    private lateinit var modeButton: Button
    private lateinit var flashButton: Button
    private lateinit var zoomText: TextView
    private lateinit var zoomSeek: SeekBar
    private lateinit var statusText: TextView

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.CAMERA] == true) startCamera()
        else toast("Permissão de câmera necessária.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = Executors.newSingleThreadExecutor()
        buildInterface()
        if (hasPermissions()) startCamera() else requestPermissionsNow()
    }

    private fun buildInterface() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 18, 20, 12)
            setBackgroundColor(0x66090B10)
        }
        val title = TextView(this).apply {
            text = "OXYGEN  •  CAMERA 16"
            textSize = 15f
            setTextColor(Color.WHITE)
            letterSpacing = .08f
        }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        flashButton = glassButton("FLASH OFF") { toggleFlash() }
        top.addView(flashButton)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 16, 20, 28)
            setBackgroundColor(0xCC090B10.toInt())
        }

        statusText = TextView(this).apply {
            text = "FOTO  •  AUTO"
            textSize = 12f
            letterSpacing = .12f
            setTextColor(0xFFDCE7F5.toInt())
            gravity = Gravity.CENTER
        }
        bottom.addView(statusText)

        zoomText = TextView(this).apply {
            text = "1.0×"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 0)
        }
        bottom.addView(zoomText)

        zoomSeek = SeekBar(this).apply {
            max = 100
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val info = camera?.cameraInfo ?: return
                    val min = info.zoomState.value?.minZoomRatio ?: 1f
                    val maxZoom = info.zoomState.value?.maxZoomRatio ?: 1f
                    val ratio = min + (maxZoom - min) * progress / 100f
                    camera?.cameraControl?.setZoomRatio(ratio)
                    zoomText.text = String.format(Locale.US, "%.1f×", ratio)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        bottom.addView(zoomSeek, LinearLayout.LayoutParams(-1, -2))

        val modes = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        modeButton = glassButton("FOTO  |  VÍDEO") { toggleMode() }
        modes.addView(modeButton)
        bottom.addView(modes)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val switch = glassButton("GIRAR") { switchCamera() }
        controls.addView(switch)
        captureButton = Button(this).apply {
            text = "●"
            textSize = 25f
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFDFE8F2.toInt())
                setStroke(5, Color.WHITE)
            }
            setOnClickListener { if (videoMode) toggleRecording() else takePhoto() }
        }
        val capParams = LinearLayout.LayoutParams(76, 76).apply {
            setMargins(28, 0, 28, 0)
        }
        controls.addView(captureButton, capParams)
        val gallery = glassButton("GALERIA") { openGallery() }
        controls.addView(gallery)
        bottom.addView(controls)
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun glassButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 10f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 40f
                setColor(0x553D4655)
                setStroke(1, 0x66FFFFFF)
            }
            setPadding(14, 8, 14, 8)
            setOnClickListener { action() }
        }
    }

    private fun hasPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsNow() {
        val requested = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT <= 32) {
            requested.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissions.launch(requested.toTypedArray())
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.FHD))
                .build()
            videoCapture = VideoCapture.withOutput(recorder)
            try {
                provider.unbindAll()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                camera = provider.bindToLifecycle(
                    this, selector, preview, imageCapture, videoCapture
                )
                zoomSeek.progress = 0
                zoomText.text = "1.0×"
            } catch (e: Exception) {
                toast("Câmera indisponível: ${e.localizedMessage}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val name = "Oxygen_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OxygenCamera16")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    toast("Foto salva.")
                }
                override fun onError(exception: ImageCaptureException) {
                    toast("Falha ao fotografar: ${exception.message}")
                }
            })
    }

    private fun toggleRecording() {
        val active = recording
        if (active != null) {
            active.stop()
            recording = null
            captureButton.text = "●"
            statusText.text = "VÍDEO  •  SALVANDO"
            return
        }
        val capture = videoCapture ?: return
        val name = "Oxygen_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/OxygenCamera16")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()
        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pending = pending.withAudioEnabled()
        }
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    captureButton.text = "■"
                    statusText.text = "VÍDEO  •  GRAVANDO"
                }
                is VideoRecordEvent.Finalize -> {
                    captureButton.text = "●"
                    statusText.text = "VÍDEO  •  AUTO"
                    if (!event.hasError()) toast("Vídeo salvo.")
                    else toast("Erro ao salvar vídeo.")
                }
            }
        }
    }

    private fun toggleMode() {
        if (recording != null) return
        videoMode = !videoMode
        statusText.text = if (videoMode) "VÍDEO  •  AUTO" else "FOTO  •  AUTO"
        captureButton.text = "●"
    }

    private fun toggleFlash() {
        val hasFlash = camera?.cameraInfo?.hasFlashUnit() == true
        if (!hasFlash) {
            toast("Flash não disponível nesta câmera.")
            return
        }
        torchOn = !torchOn
        camera?.cameraControl?.enableTorch(torchOn)
        flashButton.text = if (torchOn) "FLASH ON" else "FLASH OFF"
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { toast("Nenhuma galeria encontrada.") }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        recording?.stop()
        executor.shutdown()
        super.onDestroy()
    }
}
